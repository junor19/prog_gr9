# Release Notes

## [1.0.0] - 2025-03-05

### Added/Changed

- Added .gitigonre

### Fixed


### Author

- Changes made by Majid Rouhani
