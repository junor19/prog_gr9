# KI Deklarasjon

Du finner mer informasjon om rettningslinjer i forbindelse med bruk av KI [her](https://i.ntnu.no/wiki/-/wiki/Norsk/Kunstig+intelligens+i+bachelor-+og+masteroppgaver).

Undertegnet [KI-deklarasjon](./ki-deklarasjon.pdf) av hver enkel medlem i gruppen skal leveres sammen med resten av prosjektbesvarelsen.
